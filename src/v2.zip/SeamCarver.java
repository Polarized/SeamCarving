public class SeamCarver {
	private final float BORDER_ENERGY = 195075;
	private Picture currentPic;
	private boolean removed[][];
	private float pixelEnergy[][];
	private boolean T = false;  // false for vertical processing, true for horizontal processing
	private int myWidth;
	private int myHeight;
	
	public SeamCarver(Picture picture) {
	   if (picture == null) throw new NullPointerException();
	   
	   this.pixelEnergy = new float[picture.height()][picture.width()];
	   
	   this.removed = new boolean[picture.height()][picture.width()];
	   
	   this.myHeight = picture.height();
	   
	   this.myWidth = picture.width();
	   
	   this.currentPic = picture;
	   
	   this.computeEnergy();
    }
   
	
	public Picture picture() {
		Picture newPic = new Picture(this.myWidth, this.myHeight);
		
		int width = this.width();
		int height = this.height();
		
//		if (T) {
//			this.transpose();
//			this.T = false;
//		}
		
		for (int row = 0; row < height; row++) {
			for (int col = 0; col < width; col++) {
				if (removed[row][col]) continue;
				newPic.set(col, row, this.currentPic.get(col, row));
			}
		}
		this.currentPic = newPic; // needed?
		return newPic; 
	}
   
	
	public int width()  {
	   // width  of current picture
		if (T) return this.currentPic.height();
	   return this.currentPic.width();
   
	}
	
	public int height() {
	   // height of current picture
		if (T) return this.currentPic.width();
	   return this.currentPic.height();
   
	}
   
	public double energy(int x, int y) {
	   // energy of pixel at column x and row y in current picture
		if (x < 0 || x >= this.width()) throw new IndexOutOfBoundsException();
		if (y < 0 || y >= this.height()) throw new IndexOutOfBoundsException();
		if (y == 0 || y == this.height() - 1 || x == 0 || x == this.width() - 1 ) {
			return BORDER_ENERGY;
		}
		return xGradient(y, x) + yGradient(y, x);
	}
   
	
	public int[] findHorizontalSeam() {
	   // sequence of indices for horizontal seam in current picture
//		if(!T) {
//			// transpose
//			this.transpose();
//			this.T = true;
//		}
//		
//		int [] edgeTo = new int [this.height() * this.width()];
//		double [] energyAt = new double [this.height()];
//		
//		// fill energyAt array with first column energies
//		// fill edgeTo with starting vertices
//		for (int row = 0; row < energyAt.length; row++) {
//			energyAt[row] = this.energy(0 , row);
//			edgeTo[row] = row;
//		}
//		
//		// for each vertex or pixel relax the incoming edges
//		// update edgeTo and energyAt arrays
//        for (int col = 1; col < this.width(); col++) {
//        	for (int row = 0; row < this.height(); row++) {
//        		relax(col, row, energyAt, edgeTo);
//        	}
//        }
//        
//        int minEnergyIndex = getMin(energyAt);
        this.transpose(this.removed);
        this.transpose(this.pixelEnergy);
        this.T = true;
        int[] seam = this.findVerticalSeam();
        this.transpose(this.removed);
        this.transpose(this.pixelEnergy);
        this.T = false;
        return seam;
	}
   
	
	public int[] findVerticalSeam() {
	   // sequence of indices for vertical seam in current picture
//		if(T) {
//			// transpose back
//			this.transpose();
//			this.T = false;
//		}
		
		int [] edgeTo = new int [this.height() * this.width()];
		//float[][] distTo = new float[this.height()][this.width()];
		
		// fill energyAt array with first row energies
		// fill edgeTo with starting vertices
//		for (int col = 0; col < disTo.length; col++) {
//			disTo[col] = this.energy(col , 0);
//			edgeTo[col] = col;
//		}
		
		// for each vertex or pixel relax the incoming edges
		// update edgeTo and distTo arrays
        for (int row = 1; row < this.height(); row++) {
        	for (int col = 0; col < this.width(); col++) {
        		relax(row, col, edgeTo);
        	}
        }
        
        int minEnergyIndex = getMin();
        
        return getSeam(minEnergyIndex, edgeTo);
	}


	public void removeHorizontalSeam(int[] a) {
	   // remove horizontal seam from current picture
		if (a.length != this.width()) throw new IllegalArgumentException();
		if (this.width() <= 1 || this.height() <= 1) throw new IllegalArgumentException();
		
//		if(!T) {
//			this.transpose();
//			this.T = true;
//		}
//		
//		for (int col = 0; col < a.length; col++) {
//			removed[col][a[col]] = true;
//		}
//		
//		this.myHeight--;
        this.transpose(this.removed);
        this.transpose(this.pixelEnergy);
        this.T = true;
        this.removeVerticalSeam(a);
        this.transpose(this.removed);
        this.transpose(this.pixelEnergy);
        this.T = false;
	}
   
	
	public void removeVerticalSeam(int[] a) {
	   // remove vertical seam from current picture
		if (a.length != this.height()) throw new IllegalArgumentException();
		if (this.width() <= 1 || this.height() <= 1) throw new IllegalArgumentException();
		
//		if(T) {
//			this.transpose();
//			this.T = false;
//		}
		
		for (int row = 0; row < a.length; row++) {
			removed[row][a[row]] = true;
		}
		
		this.myWidth--;
		
//		float[][] copy = new float[this.height()][this.width() - 1];
//		
//		for (int i = 0 ; i < a.length; i++) {
//			if (a[i] == 0) {
//				System.arraycopy(energy[i], 1, copy[i], 0, energy[i].length);
//				copy[i][0] = BORDER_ENERGY;
//			}
//			else if (a[i] == energy[i].length - 1) {
//				System.arraycopy(energy[i], 0, copy[i], 0, copy[i].length);
//				copy[i][copy[i].length - 1] = BORDER_ENERGY;				
//			}
//			else {
//			    System.arraycopy(energy[i], 0, copy[i], 0, a[i]);
//			    System.arraycopy(energy[i], a[i] + 1, copy, a[i], energy[i].length - a[i]);
//			}
//		}
//		this.updateEnergy(copy);
	}
	
	private void computeEnergy() {
		for (int row = 0; row < this.pixelEnergy.length; row++) {
			for (int col = 0; col < this.pixelEnergy[row].length; col++) {
				this.pixelEnergy[row][col] = (float) this.energy(col, row);
			}
		}
	}
	private void transpose(boolean[][] a) {
		int height = a.length;
		int width = a[0].length;
		boolean[][] t = new boolean[width][height];

		for (int row = 0; row < a.length; row++) {
			for (int col = 0; col < a[row].length; col++) {
				t[col][row] = a[row][col];
			}
		}
		a = t;
//		for (int row = 0; row < energy.length; row++) {
//			for (int col = 0; col < energy[row].length; col++) {
//				boolean temp = this.energy[col][row];
//				this.energy[col][row] = this.energy[row][col];
//				this.energy[row][col] = temp;
//			}
//		}
	}
	
	private void transpose(float[][] a) {
		int height = a.length;
		int width = a[0].length;
		float[][] t = new float[width][height];

		for (int row = 0; row < a.length; row++) {
			for (int col = 0; col < a[row].length; col++) {
				t[col][row] = a[row][col];
			}
		}
		a = t;
	}
	
	private int[] getSeam(int minEnergyIndex, int[] edgeTo) {
		int[] seam;
		int vertex;
		if (T) {
			seam = new int[this.width()];
			seam[seam.length - 1] = minEnergyIndex;
			vertex = this.getVertexID(this.width() - 1, minEnergyIndex);
			for (int col = seam.length - 2; col >= 0; col--) {
				vertex = edgeTo[vertex];
				seam[col] = this.getRow(vertex);
			}
		}
		else {
			seam = new int[this.height()];			
			seam[seam.length - 1] = minEnergyIndex;		
			vertex = this.getVertexID(this.height() - 1, minEnergyIndex);			
			for (int row = seam.length - 2; row >= 0; row--) {	
				vertex = edgeTo[vertex];
				seam[row] = this.getCol(vertex);
			}
		}
		return seam;
	}

	private int getMin() {
		int width = this.width();
		int height = this.height();
		int minIndex = 0;
		float min = Float.MAX_VALUE;
		for (int col = 0; col < width; col++) {
			if (this.pixelEnergy[height - 1][col] < min) {
				min = this.pixelEnergy[height - 1][col];
				minIndex = col;
			}
		}
		return minIndex;
	}
	
	private void relax(int row, int col, int[] edgeTo) {
		// get neighbors of current vertex
		// for each neighbor calculate the energy + current Energy
		int minNeighbor = 0;
		double minEnergy = Double.MAX_VALUE;
		
//		for (int id : getNeighbors(row, col)) {
//			if (T) {
//			    if (minEnergy > this.energy(col,row) + distTo[this.getRow(id)]) {
//				    minNeighbor = id;
//				    minEnergy = this.energy(col,row) + energyAt[this.getRow(id)];
//			    }
//			    energyAt[row] = minEnergy;
//			}
//			else {
//			    if (minEnergy >= this.energy(col,row) + energyAt[this.getCol(id)]) {
//				    minNeighbor = id;
//				    minEnergy = this.energy(col,row) + energyAt[this.getCol(id)];
//				    energyAt[col] = minEnergy;
//				    edgeTo[this.getVertexID(row, col)] = minNeighbor;
//			    }
//			    
//			}
//		}
		
		for (int id : getNeighbors(row, col)) {
			if (this.pixelEnergy[this.getRow(id)][this.getCol(id)] < minEnergy) {
				minNeighbor = id;
				minEnergy = this.pixelEnergy[this.getRow(id)][this.getCol(id)];
			}
		}
		this.pixelEnergy[row][col] += minEnergy;
		edgeTo[this.getVertexID(row, col)] = minNeighbor;
	}
	
	private int[] getNeighbors(int row, int col) {
		// get each of the neighbors that point to the current vertex
		// for vertices on the border you will have two neighbors
		// for vertices not on the border you will have three neighbors
		int [] neighbors;
		if (T) {
		    if (row == 0) {
			    neighbors = new int[2];
			    neighbors[0] = this.getVertexID(row, col - 1);
			    neighbors[1] = this.getVertexID(row + 1, col - 1);
		    }
		    else if (row == this.height() - 1) {
			    neighbors = new int[2];
			    neighbors[0] = this.getVertexID(row - 1, col - 1);
			    neighbors[1] = this.getVertexID(row, col - 1);
		    }
		    else {
			    neighbors = new int[3];
			    neighbors[0] = this.getVertexID(row - 1, col - 1);
			    neighbors[1] = this.getVertexID(row, col - 1);
			    neighbors[2] = this.getVertexID(row + 1, col - 1);
		    }
		}
		else {
		    if (col == 0) {
			    neighbors = new int[2];
			    neighbors[0] = this.getVertexID(row - 1, col);
			    neighbors[1] = this.getVertexID(row - 1, col + 1);
		    }
		    else if (col == this.width() - 1) {
			    neighbors = new int[2];
			    neighbors[0] = this.getVertexID(row - 1, col - 1);
			    neighbors[1] = this.getVertexID(row - 1, col);
		    }
		    else {
			    neighbors = new int[3];
			    neighbors[0] = this.getVertexID(row - 1, col - 1);
			    neighbors[1] = this.getVertexID(row - 1, col);
			    neighbors[2] = this.getVertexID(row - 1, col + 1);
		    }
		}
		return neighbors;
	}
	
	private float yGradient(int y, int x) {
		float r = Math.abs(this.currentPic.get(x, y - 1).getRed() - this.currentPic.get(x, y + 1).getRed());
		
		float g = Math.abs(this.currentPic.get(x, y - 1).getGreen() - this.currentPic.get(x, y + 1).getGreen());
		
		float b = Math.abs(this.currentPic.get(x, y - 1).getBlue() - this.currentPic.get(x, y + 1).getBlue());
		
		return r*r + g*g + b*b;
	}
	
	private float xGradient(int y, int x) {
		float r = Math.abs(this.currentPic.get(x - 1, y).getRed() - this.currentPic.get(x + 1, y).getRed());
		
		float g = Math.abs(this.currentPic.get(x - 1, y).getGreen() - this.currentPic.get(x + 1, y).getGreen());
		
		float b = Math.abs(this.currentPic.get(x - 1, y).getBlue() - this.currentPic.get(x + 1, y).getBlue());
		
		return r*r + g*g + b*b;
	}
	
	private int getVertexID(int r, int c) {
		int W = this.width();
		return W * r + c;
	}
	
	private int getRow(int id) {
		int W = this.width();
		return id / W;
	}
	
	private int getCol(int id) {
		int W = this.width();
		return id % W;
	}
}